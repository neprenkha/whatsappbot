'use strict';

const Conf = require('../Shared/SharedConfV1');
const RoleGate = require('../Shared/SharedRoleGateV1');
const SafeSend = require('../Shared/SharedSafeSendV1');

module.exports = function FallbackCV(meta) {
  const rawCfg = meta.implConf || meta.moduleConf || {};

  const cfg = {
    enabled: Conf.toBool(rawCfg.enabled, 1),
    controlGroupId: Conf.toStrTrim(rawCfg.controlGroupId, ''),
    requiredRole: Conf.toStrTrim(rawCfg.requiredRole, 'staff'),
    accessService: Conf.toStrTrim(rawCfg.accessService, 'access'),
    replyCmd: Conf.toStrTrim(rawCfg.replyCmd, 'r'),
    workGroupsService: Conf.toStrTrim(rawCfg.workGroupsService, 'workgroups'),
    ticketService: Conf.toStrTrim(rawCfg.ticketService, 'ticketseq'),
    ticketPrefix: Conf.toStrTrim(rawCfg.ticketPrefix, 'T'),
    outboxService: Conf.toStrTrim(rawCfg.outboxService, 'outbox'),
    sendPrefer: Conf.parseCsv(Conf.toStrTrim(rawCfg.sendPrefer, 'outsend,sendout,send')),
    forwardMyStatus: Conf.toBool(rawCfg.forwardMyStatus, 0),
  };

  function log(tag, msg) {
    if (meta && typeof meta.log === 'function') meta.log(tag, msg);
  }

  function nowIso() {
    return new Date().toISOString();
  }

  function safeText(v) {
    return Conf.toStrTrim(v, '');
  }

  function extractPhone(sender) {
    const p = String((sender && sender.phone) || '').replace(/\D/g, '');
    return p || '';
  }

  function extractLidDigitsFromSender(sender) {
    const lidRaw = String((sender && sender.lid) || '');
    const lidDigits = lidRaw.replace(/\D/g, '');
    if (lidDigits) return lidDigits;
    const id = String((sender && sender.id) || '');
    const m = id.match(/^(\d+)@lid$/);
    return m ? m[1] : '';
  }

  function normalizeSenderId(sender) {
    const lid = extractLidDigitsFromSender(sender);
    if (lid) return `lid:${lid}`;
    const phone = String((sender && sender.phone) || '').replace(/\D/g, '');
    if (phone) return `phone:${phone}`;
    const id = String((sender && sender.id) || '');
    return id || '';
  }

  function pickTextSender(meta2) {
    const prefer = Array.isArray(cfg.sendPrefer)
      ? cfg.sendPrefer
      : Conf.parseCsv(cfg.sendPrefer || 'outsend,sendout,send');

    for (const svcName of prefer) {
      const svc = meta2.getService(svcName);
      if (svc && typeof svc.send === 'function') return svc;
    }
    return null;
  }

  async function nextTicket() {
    const svc = meta.getService(cfg.ticketService);
    if (!svc || typeof svc.next !== 'function') return `${cfg.ticketPrefix}${Date.now()}`;
    return svc.next(cfg.ticketPrefix);
  }

  function buildCard(ticketId, ctx) {
    const senderPhone = extractPhone(ctx.sender);
    const senderName = safeText(ctx.sender && ctx.sender.name) || '-';
    const chatId = safeText(ctx.chatId);

    const lines = [];
    lines.push('[Fallback]');
    lines.push(`Ticket: ${ticketId}`);
    lines.push(`From: ${senderName}`);
    lines.push(`Phone: ${senderPhone || '-'}`);
    lines.push(`ChatId: ${chatId || '-'}`);
    lines.push(`At: ${nowIso()}`);
    lines.push('');
    lines.push('Message:');
    lines.push(safeText(ctx.text) || '(empty)');
    lines.push('');
    lines.push(`Reply: quote-reply this card, or use: !${cfg.replyCmd} ${ticketId} <text>`);
    return lines.join('\n');
  }

  function parseTicketFromText(text) {
    const t = safeText(text);
    if (!t) return '';
    const m = t.match(/Ticket:\s*([A-Za-z0-9]+)/i);
    return m ? m[1] : '';
  }

  function parsePhoneFromText(text) {
    const t = safeText(text);
    if (!t) return '';
    const m = t.match(/Phone:\s*([0-9]+)/i);
    return m ? m[1] : '';
  }

  async function handleRCommand(ctx) {
    if (!cfg.enabled) return;

    const senderId = ctx.senderId || normalizeSenderId(ctx.sender);
    const allowed = await RoleGate.isAllowed(meta, cfg.accessService, senderId, cfg.requiredRole);
    if (!allowed) {
      await ctx.reply('You are not allowed to run this command.');
      return;
    }

    const args = Array.isArray(ctx.args) ? ctx.args : [];
    const ticketId = safeText(args[0]);
    const text = safeText(args.slice(1).join(' '));

    if (!ticketId || !text) {
      await ctx.reply(`Usage: !${cfg.replyCmd} <ticketId> <text>`);
      return;
    }

    await ctx.reply('OK. Sending reply...');
    log('FallbackCV', `reply.sent ticket=${ticketId}`);
    // Real send to customer is handled in quote reply flow (recommended).
    // !r is kept as fallback only.
  }

  async function handleInboundDm(ctx) {
    const groupId = cfg.controlGroupId;
    if (!groupId) return;

    // If message is from status@broadcast, ignore by default
    if (!cfg.forwardMyStatus && ctx.chatId === 'status@broadcast') return;

    const senderPhone = extractPhone(ctx.sender);
    if (!senderPhone) return;

    const ticketId = await nextTicket();
    const card = buildCard(ticketId, ctx);

    await SafeSend.sendOrQueue(meta, cfg, groupId, card);
    log('FallbackCV', `dm.forwarded ticket=${ticketId} from=${senderPhone}`);
  }

  async function handleQuoteReply(ctx) {
    const wg = meta.getService(cfg.workGroupsService);
    const inAllowed =
      wg && typeof wg.isAllowedGroup === 'function'
        ? wg.isAllowedGroup(ctx.chatId)
        : (cfg.controlGroupId && ctx.chatId === cfg.controlGroupId);

    if (!inAllowed) return;

    const senderId = normalizeSenderId(ctx.sender);
    const allowed = await RoleGate.isAllowed(meta, cfg.accessService, senderId, cfg.requiredRole);
    if (!allowed) return;

    const msg = ctx.message;
    if (!msg) return;

    // whatsapp-web.js style
    if (typeof msg.hasQuotedMsg !== 'function') return;
    const has = await msg.hasQuotedMsg();
    if (!has) return;

    const quoted = await msg.getQuotedMessage();
    if (!quoted || !quoted.body) return;

    const ticketId = parseTicketFromText(quoted.body);
    const toPhone = parsePhoneFromText(quoted.body);
    if (!ticketId || !toPhone) return;

    const text = safeText(ctx.text);
    if (text) await SafeSend.sendOrQueue(meta, cfg, `phone:${toPhone}`, text);
    log('FallbackCV', `reply.sent ticket=${ticketId} to=${toPhone}`);
  }

  async function init() {
    const cmd = meta.getService('command');
    if (cmd && typeof cmd.register === 'function') {
      cmd.register(cfg.replyCmd, handleRCommand);
    }

    log('FallbackCV', `ready enabled=${cfg.enabled ? 1 : 0} controlGroupId=${cfg.controlGroupId || '-'}`);
  }

  async function onMessage(ctx) {
    try {
      if (!cfg.enabled) return;

      if (!ctx || !ctx.chatId) return;

      // Prevent loops
      if (ctx.message && ctx.message.fromMe) {
        if (!ctx.isGroup) log('FallbackCV', `skip fromMe dm chatId=${ctx.chatId}`);
        return;
      }

      // Quote reply flow in groups
      if (ctx.isGroup) {
        await handleQuoteReply(ctx);
        return;
      }

      // DM forward
      await handleInboundDm(ctx);
    } catch (e) {
      log('FallbackCV', `onMessage error=${String(e)}`);
    }
  }

  return { init, onMessage };
};
