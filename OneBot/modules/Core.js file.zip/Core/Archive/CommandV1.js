'use strict';

const Conf = require('../Shared/SharedConfV1');

/**
 * CommandV1
 * - Parse incoming text commands
 * - Route to registered handlers
 * - Provide friendly replies and tips
 *
 * Config:
 *   prefix=!
 *   allowInDm=1
 *   allowInGroups=1
 *   tipsFile=...
 *   unknownText=Unknown command.
 *   errorPrefix=Error:
 */

module.exports = function CommandV1(meta) {
  const log = (msg) => meta && typeof meta.log === 'function' && meta.log('CommandV1', msg);

  const rawCfg = meta.implConf || meta.moduleConf || {};
  const conf = {
    prefix: Conf.toStrTrim(rawCfg.prefix, '!'),
    allowInDm: Conf.toBool(rawCfg.allowInDm, 1),
    allowInGroups: Conf.toBool(rawCfg.allowInGroups, 1),
    tipsFile: Conf.toStrTrim(rawCfg.tipsFile, ''),
    unknownText: Conf.toStrTrim(rawCfg.unknownText, 'Unknown command.'),
    errorPrefix: Conf.toStrTrim(rawCfg.errorPrefix, 'Error: '),
  };

  const registry = new Map();
  let tips = { text: '', updatedAt: 0 };

  function toStr(v, defVal) {
    if (v === null || v === undefined) return defVal;
    return String(v);
  }

  function trim(v) {
    return toStr(v, '').trim();
  }

  function extractLidDigits(sender) {
    const lidRaw = trim(sender && sender.lid);
    const lidDigits = lidRaw.replace(/\D/g, '');
    if (lidDigits) return lidDigits;

    const id = trim(sender && sender.id);
    const m = id.match(/^(\d+)@lid$/);
    return m ? m[1] : '';
  }

  function normalizeSenderId(sender) {
    const lid = extractLidDigits(sender);
    if (lid) return `lid:${lid}`;

    const phone = toStr(sender && sender.phone, '').replace(/\D/g, '');
    if (phone) return `phone:${phone}`;

    const id = toStr(sender && sender.id, '');
    return id || '';
  }

  async function sendTextVia(meta2, serviceName, chatId, text) {
    const svc = meta2.getService(serviceName);
    if (!svc || typeof svc.send !== 'function') return false;
    await svc.send(chatId, text);
    return true;
  }

  async function sendText(chatId, text) {
    const prefer = Conf.parseCsv(conf.sendPrefer || 'outsend,sendout,send');
    for (const svcName of prefer) {
      if (!svcName) continue;
      try {
        const ok = await sendTextVia(meta, svcName, chatId, text);
        if (ok) return true;
      } catch (_) {}
    }
    return false;
  }

  function parseTokens(text) {
    const t = trim(text);
    if (!t) return { cmd: '', args: [] };
    const parts = t.split(/\s+/g);
    const cmd = (parts.shift() || '').trim();
    const args = parts;
    return { cmd, args };
  }

  function shouldHandle(ctx) {
    if (!ctx) return false;
    if (ctx.isGroup && !conf.allowInGroups) return false;
    if (!ctx.isGroup && !conf.allowInDm) return false;
    return true;
  }

  function register(cmdName, handler, opt) {
    const name = trim(cmdName).toLowerCase();
    if (!name) return;
    const entry = {
      cmd: name,
      handler,
      minRole: opt && opt.minRole ? trim(opt.minRole) : '',
      help: opt && opt.help ? trim(opt.help) : '',
    };
    registry.set(name, entry);
  }

  async function loadTipsOnce() {
    try {
      const fs = require('fs');
      const path = require('path');
      const file = trim(conf.tipsFile);
      if (!file) return;
      const abs = path.isAbsolute(file) ? file : path.join(meta.dataDir || '', file);
      if (!fs.existsSync(abs)) return;
      const st = fs.statSync(abs);
      if (!tips.updatedAt || st.mtimeMs > tips.updatedAt) {
        tips.text = fs.readFileSync(abs, 'utf-8');
        tips.updatedAt = st.mtimeMs;
        log(`tips.loaded file=${abs}`);
      }
    } catch (e) {
      log(`tips.load error=${String(e)}`);
    }
  }

  async function onMessage(ctx) {
    try {
      if (!shouldHandle(ctx)) return;

      const msg = ctx.message;
      const text = trim(ctx.text);
      if (!text) return;

      const p = trim(conf.prefix);
      if (!p) return;
      if (!text.startsWith(p)) return;

      await loadTipsOnce();

      const body = text.slice(p.length);
      const parsed = parseTokens(body);
      const cmd = trim(parsed.cmd).toLowerCase();
      const args = parsed.args || [];

      const senderId = normalizeSenderId(msg && msg.sender);
      const senderLid = extractLidDigits(msg && msg.sender);

      const entry = registry.get(cmd);
      if (!entry) {
        const unknownText = toStr(conf.unknownText, 'Unknown command.').trim() || 'Unknown command.';
        if (ctx && typeof ctx.reply === 'function') {
          await ctx.reply(unknownText);
          return;
        }
        if (ctx && ctx.chatId) await sendText(ctx.chatId, unknownText);
        return;
      }

      const childCtx = Object.assign({}, ctx, {
        command: cmd,
        args,
        senderId,
        senderLid,
        reply: async (t) => {
          if (ctx && typeof ctx.reply === 'function') return ctx.reply(t);
          if (ctx && ctx.chatId) return sendText(ctx.chatId, t);
          return false;
        },
      });

      await entry.handler(childCtx);
    } catch (err) {
      try {
        const chatId = ctx && ctx.chatId;
        const msg = `${conf.errorPrefix}${String(err)}`;
        if (chatId) await sendText(chatId, msg);
      } catch (_) {}
      log(`onMessage error=${String(err)}`);
    }
  }

  meta.registerService('command', { register });
  meta.registerService('commands', { register });

  log(`ready prefix=${conf.prefix} allowInDm=${conf.allowInDm ? 1 : 0} allowInGroups=${conf.allowInGroups ? 1 : 0}`);
  return { onMessage };
};
