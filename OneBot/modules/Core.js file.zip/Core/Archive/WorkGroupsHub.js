'use strict';

const path = require('path');

function mkLog(meta) {
  const base = meta && meta.log;
  const tag = 'WorkGroupsHub';

  function emit(level, msg) {
    try {
      // Pattern A: base is function(tag, msg)
      if (typeof base === 'function') return base(tag, msg);

      // Pattern B: base has .info/.warn/.error
      if (base && typeof base[level] === 'function') return base[level](`[${tag}] ${msg}`);

      // Fallback
      return console.log(`[${tag}] ${level} ${msg}`);
    } catch (_) {
      try { console.log(`[${tag}] ${level} ${msg}`); } catch (_) {}
    }
  }

  return {
    info: (m) => emit('info', m),
    warn: (m) => emit('warn', m),
    error: (m) => emit('error', m),
  };
}

function noopModule() {
  return {
    onMessage: async () => {},
    onEvent: async () => {},
  };
}

module.exports = {
  id: 'WorkGroupsHub',

  init: async (meta) => {
    const log = mkLog(meta);

    try {
      const hubConfRel = meta && meta.moduleConf && meta.moduleConf.config;
      if (!hubConfRel) {
        log.error('missing moduleConf.config (Hub conf path)');
        return noopModule();
      }

      // IMPORTANT: loadConfRel returns { absPath, conf }
      const loadedHub = await meta.loadConfRel(hubConfRel);
      const hubConf = (loadedHub && loadedHub.conf) ? loadedHub.conf : loadedHub;

      const enabled = String((hubConf && hubConf.enabled) ?? '1') !== '0';
      if (!enabled) {
        log.info('disabled');
        return noopModule();
      }

      const implFile = String((hubConf && hubConf.implFile) || '').trim();
      if (!implFile) {
        log.error(`missing implFile in ${hubConfRel}`);
        return noopModule();
      }

      const implConfigRel = String((hubConf && hubConf.implConfig) || '').trim();

      let implCfg = {};
      if (implConfigRel) {
        const loadedImpl = await meta.loadConfRel(implConfigRel);
        implCfg = (loadedImpl && loadedImpl.conf) ? loadedImpl.conf : (loadedImpl || {});
      }

      const implAbs = path.isAbsolute(implFile) ? implFile : path.join(meta.codeRoot, implFile);

      // Require implementation
      // Expected export: { init: async (meta, cfg) => ({ onMessage, onEvent }) }
      // Also supports: module.exports = async (meta, cfg) => ({...})
      const impl = require(implAbs);

      const implInit =
        (impl && typeof impl.init === 'function') ? impl.init :
        (typeof impl === 'function') ? impl :
        null;

      if (!implInit) {
        log.error(`impl has no init(): ${implFile}`);
        return noopModule();
      }

      const mod = await implInit(meta, implCfg);
      return mod || noopModule();
    } catch (e) {
      const msg = (e && e.stack) ? e.stack : String(e);
      try { mkLog(meta).error(msg); } catch (_) {}
      return noopModule();
    }
  },
};
