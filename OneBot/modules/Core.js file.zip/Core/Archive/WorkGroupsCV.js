'use strict';

// WorkGroupsCV.js
// - Provides !group commands in Control Group
// - Provides a small WorkGroups service for other modules (e.g., Fallback)

const Conf = require('../Shared/SharedConfV1');
const RoleGate = require('../Shared/SharedRoleGateV1');

module.exports = function WorkGroupsCV(meta) {
  const rawCfg = meta.implConf || meta.moduleConf || {};

  const cfg = {
    enabled: Conf.toBool(rawCfg.enabled, 1),
    controlGroupId: Conf.toStrTrim(rawCfg.controlGroupId, ''),
    requiredRole: Conf.toStrTrim(rawCfg.requiredRole, 'admin'),
    cmdGroup: Conf.toStrTrim(rawCfg.cmdGroup, 'group'),

    storeService: Conf.toStrTrim(rawCfg.storeService, 'jsonstore'),
    storeNs: Conf.toStrTrim(rawCfg.storeNs, 'WorkGroups'),
    storeKey: Conf.toStrTrim(rawCfg.storeKey, 'state'),
  };

  function log(msg) {
    if (meta && typeof meta.log === 'function') meta.log('WorkGroupsCV', msg);
  }

  let storeSvc = null;
  let stateCache = { groups: {}, updatedAt: 0 };

  function asChatId(val) {
    if (!val) return '';
    if (typeof val === 'string') return val;
    if (typeof val === 'object' && typeof val.chatId === 'string') return val.chatId;
    return '';
  }

  function normalizeName(name) {
    const s = Conf.toStrTrim(name, '').toLowerCase();
    const cleaned = s.replace(/[^a-z0-9]/g, '');
    return cleaned;
  }

  async function loadState() {
    try {
      if (!storeSvc || typeof storeSvc.open !== 'function') return { groups: {}, updatedAt: 0 };
      const st = storeSvc.open(cfg.storeNs);
      const state = (await st.get(cfg.storeKey)) || { groups: {}, updatedAt: 0 };
      if (!state.groups || typeof state.groups !== 'object') state.groups = {};
      return state;
    } catch (e) {
      log(`state.load error=${String(e)}`);
      return { groups: {}, updatedAt: 0 };
    }
  }

  async function saveState(state) {
    try {
      if (!storeSvc || typeof storeSvc.open !== 'function') return;
      const st = storeSvc.open(cfg.storeNs);
      state.updatedAt = Date.now();
      await st.set(cfg.storeKey, state);
    } catch (e) {
      log(`state.save error=${String(e)}`);
    }
  }

  function isAllowedGroup(chatId) {
    if (!chatId) return false;
    if (cfg.controlGroupId && chatId === cfg.controlGroupId) return true;
    const groups = (stateCache && stateCache.groups) || {};
    for (const k of Object.keys(groups)) {
      if (asChatId(groups[k]) === chatId) return true;
    }
    return false;
  }

  function listGroups() {
    const out = [];
    if (cfg.controlGroupId) out.push({ name: 'control', chatId: cfg.controlGroupId });
    const groups = (stateCache && stateCache.groups) || {};
    for (const name of Object.keys(groups).sort()) {
      out.push({ name, chatId: asChatId(groups[name]) });
    }
    return out;
  }

  async function ensureAllowed(ctx) {
    if (!cfg.enabled) return false;

    if (!ctx || !ctx.isGroup) {
      if (ctx && typeof ctx.reply === 'function') await ctx.reply('Use this in the Control Group.');
      return false;
    }

    if (cfg.controlGroupId && ctx.chatId !== cfg.controlGroupId) {
      if (ctx && typeof ctx.reply === 'function') await ctx.reply('This command is only available in the Control Group.');
      return false;
    }

    const senderId = Conf.toStrTrim(ctx.senderId, '');
    const ok = await RoleGate.isAllowed(meta, 'access', senderId, cfg.requiredRole);
    if (!ok) {
      if (ctx && typeof ctx.reply === 'function') await ctx.reply('You are not allowed to run this command.');
      return false;
    }
    return true;
  }

  async function onGroupCommand(ctx) {
    if (!(await ensureAllowed(ctx))) return;

    const args = Array.isArray(ctx.args) ? ctx.args : [];
    const sub = Conf.toStrTrim(args[0], '').toLowerCase();

    // Always refresh state for admin commands
    stateCache = await loadState();

    if (!sub || sub === 'help') {
      const lines = [
        'WorkGroups',
        '',
        'Commands:',
        '!group list',
        '!group add <name> <chatId>',
        '!group del <name>',
      ];
      await ctx.reply(lines.join('\n'));
      return;
    }

    if (sub === 'list') {
      const list = listGroups();
      const lines = ['WorkGroups'];
      if (!list.length) {
        lines.push('No groups configured.');
      } else {
        for (const g of list) lines.push(`- ${g.name}: ${g.chatId}`);
      }
      await ctx.reply(lines.join('\n'));
      return;
    }

    if (sub === 'add') {
      const nameRaw = args[1];
      const chatId = Conf.toStrTrim(args[2], '');
      const name = normalizeName(nameRaw);

      if (!name || !chatId) {
        await ctx.reply('Usage: !group add <name> <chatId>');
        return;
      }

      stateCache.groups[name] = { chatId };
      await saveState(stateCache);
      await ctx.reply(`Saved: ${name} -> ${chatId}`);
      return;
    }

    if (sub === 'del' || sub === 'delete' || sub === 'remove') {
      const name = normalizeName(args[1]);
      if (!name) {
        await ctx.reply('Usage: !group del <name>');
        return;
      }

      if (!stateCache.groups[name]) {
        await ctx.reply(`Not found: ${name}`);
        return;
      }

      delete stateCache.groups[name];
      await saveState(stateCache);
      await ctx.reply(`Deleted: ${name}`);
      return;
    }

    await ctx.reply('Unknown subcommand. Try: !group help');
  }

  async function init() {
    storeSvc = meta.getService(cfg.storeService);
    stateCache = await loadState();

    const command = meta.getService('command');
    if (command && typeof command.register === 'function') {
      command.register(cfg.cmdGroup, onGroupCommand);
    }

    meta.registerService('workgroups', {
      isAllowedGroup,
      listGroups,
      getControlGroupId: () => cfg.controlGroupId,
    });

    log(`ready enabled=${cfg.enabled ? 1 : 0} controlGroupId=${cfg.controlGroupId || '-'}`);
  }

  return { init };
};
