"use strict";
module.exports = require("./MessageJournalV1");