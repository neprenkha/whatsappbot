"use strict";
module.exports = require("./RateLimitV1");