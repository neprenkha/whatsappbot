"use strict";
module.exports = require("./BootAnnounceV1");