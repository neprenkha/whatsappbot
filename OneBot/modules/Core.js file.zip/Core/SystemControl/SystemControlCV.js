"use strict";
module.exports = require("./SystemControlV2");