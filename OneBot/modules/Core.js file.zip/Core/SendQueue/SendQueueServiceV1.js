'use strict';

function createSend(meta, cfg, store, pump, Normalize) {
  return async function send(chatId, text, options = {}) {
    const id = Normalize.normalize(chatId);
    if (!id) return false;

    const body = (typeof text === 'string') ? text : String(text || '');
    const item = { chatId: id, text: body, options: options || {} };

    const r = store.enqueue(item);
    if (!r.ok) {
      try { meta.log(cfg.logPrefix || 'SendQueue', `drop chatId=${id} reason=${r.reason} max=${cfg.maxQueue}`); } catch (_) {}
      return false;
    }

    pump.kick();
    return true;
  };
}

module.exports = { createSend };
