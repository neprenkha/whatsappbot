'use strict';

// SharedConfV1
// Lightweight helpers for reading simple config values (strings/bools/csv) safely.

function toStr(v, def = '') {
  if (v === undefined || v === null) return def;
  const s = String(v);
  return s;
}

function toStrTrim(v, def = '') {
  const s = toStr(v, def);
  return s.trim();
}

function toBool(v, def = false) {
  if (v === undefined || v === null) return def;
  if (typeof v === 'boolean') return v;
  const s = String(v).trim().toLowerCase();
  if (!s) return def;
  if (['1', 'true', 'yes', 'y', 'on', 'enable', 'enabled'].includes(s)) return true;
  if (['0', 'false', 'no', 'n', 'off', 'disable', 'disabled'].includes(s)) return false;
  return def;
}

function parseCsv(v) {
  if (v === undefined || v === null) return [];
  if (Array.isArray(v)) {
    return v.map(x => String(x).trim()).filter(Boolean);
  }
  const s = String(v).trim();
  if (!s) return [];
  return s.split(',').map(x => x.trim()).filter(Boolean);
}

function readKV(obj, key, def) {
  if (!obj || typeof obj !== 'object') return def;
  if (!(key in obj)) return def;
  return obj[key];
}

module.exports = {
  toStr,
  toStrTrim,
  toBool,
  parseCsv,
  readKV
};
