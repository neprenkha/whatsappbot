'use strict';

// InboundDedupeCV
// Stable impl: Hub passes config in meta.implConf.
// Drop duplicate inbound messages within short time window.

const crypto = require('crypto');

function toInt(v, def) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}
function toBool(v, def) {
  if (v === undefined || v === null || v === '') return !!def;
  const s = String(v).trim().toLowerCase();
  if (['1','true','yes','y','on'].includes(s)) return true;
  if (['0','false','no','n','off'].includes(s)) return false;
  return !!def;
}
function safeStr(v) {
  return String(v || '').trim();
}

function getMsgId(ctx) {
  const r = ctx && ctx.raw;
  const id1 = r && r.id && (r.id._serialized || r.id.id || r.id);
  const id2 = r && r._data && r._data.id && (r._data.id._serialized || r._data.id.id);
  return safeStr(id1 || id2);
}

function hashKey(s) {
  return crypto.createHash('sha1').update(s).digest('hex');
}

module.exports.init = async function init(meta) {
  const cfg = (meta && meta.implConf) ? meta.implConf : {};

  const enabled = toBool(cfg.enabled, true);
  const dedupeSec = Math.max(1, toInt(cfg.dedupeSec, 4));
  const maxKeys = Math.max(1000, toInt(cfg.maxKeys, 8000));
  const logDrops = toBool(cfg.logDrops, false);

  // optional flags (not required)
  const hashForFromMe = toBool(cfg.hashForFromMe, true);
  const hashForCommands = toBool(cfg.hashForCommands, true);

  const tag = 'InboundDedupeV1';
  const nowSec = () => Math.floor(Date.now() / 1000);

  const seen = new Map(); // key -> expSec

  function cleanup(now) {
    // remove expired
    for (const [k, exp] of seen) {
      if (exp <= now) seen.delete(k);
    }
    // cap size
    while (seen.size > maxKeys) {
      const k = seen.keys().next().value;
      if (!k) break;
      seen.delete(k);
    }
  }

  try {
    meta.log(tag, `ready enabled=${enabled ? 1 : 0} dedupeSec=${dedupeSec} maxKeys=${maxKeys} logDrops=${logDrops ? 1 : 0} hashForFromMe=${hashForFromMe ? 1 : 0} hashForCommands=${hashForCommands ? 1 : 0}`);
  } catch (_) {}

  if (!enabled) return { onMessage: async () => {} };

  return {
    onMessage: async (ctx) => {
      try {
        const now = nowSec();
        cleanup(now);

        const msgId = getMsgId(ctx);
        let key;

        if (msgId) {
          key = `id:${msgId}`;
        } else {
          const chatId = safeStr(ctx && ctx.chatId);
          const senderId = safeStr(ctx && ctx.sender && (ctx.sender.id || ctx.sender.phone || ctx.sender.lid));
          const text = safeStr(ctx && ctx.text);
          const ts = safeStr(ctx && ctx.at) || safeStr(ctx && ctx.raw && (ctx.raw.timestamp || (ctx.raw._data && ctx.raw._data.t)));

          const isFromMe = !!(ctx && ctx.fromMe);
          const isCmd = (text || '').startsWith('!');
          const useFlags = (isFromMe && hashForFromMe) || (isCmd && hashForCommands);

          const raw = useFlags
            ? [chatId, senderId, text, ts, isFromMe ? 'ME' : 'U', isCmd ? 'CMD' : 'TXT'].join('|')
            : [chatId, senderId, text, ts].join('|');

          key = `h:${hashKey(raw)}`;
        }

        const exp = seen.get(key);
        if (exp && exp > now) {
          if (logDrops) {
            try { meta.log(tag, `drop duplicate key=${key} chatId=${safeStr(ctx && ctx.chatId)}`); } catch (_) {}
          }
          if (ctx && typeof ctx.stopPropagation === 'function') ctx.stopPropagation();
          return;
        }

        seen.set(key, now + dedupeSec);
      } catch (e) {
        try { meta.log(tag, `error ${e && e.message ? e.message : String(e)}`); } catch (_) {}
      }
    }
  };
};
