'use strict';

// X:\OneBot\Modules\Core\Fallback\FallbackCV.js
// Version: 2026.01.01
//
// Fallback module (DM -> Control Group) + reply flow.
//
// Inbound:
//   - Any customer DM to the bot is forwarded to the Control Group with a ticket.
//
// Reply (primary):
//   - In Control Group, quote-reply the forwarded message. The bot will send your text back to the customer.
//
// Reply (secondary):
//   - !r <ticket> <text>
//
// ASCII only (avoid console encoding issues).

const Conf = require('../Shared/SharedConfV1');
const TicketCore = require('../Shared/SharedTicketCoreV1');
const WidUtil = require('../Shared/SharedWidUtilV1');

function makeLogger(meta, tag) {
  return {
    info: (msg) => meta.log(tag, msg),
    warn: (msg) => meta.log(tag, `WARN ${msg}`),
    error: (msg) => meta.log(tag, `ERROR ${msg}`),
  };
}

function toText(v) {
  return String(v == null ? '' : v);
}

function extractDigits(v) {
  const s = toText(v);
  const m = s.match(/(\d{6,})/);
  return m ? m[1] : '';
}

function getSenderId(ctx) {
  // Prefer explicit sender.phone if connector provides it
  if (ctx && ctx.sender && ctx.sender.phone) return extractDigits(ctx.sender.phone) || toText(ctx.sender.phone);

  // WhatsApp-web.js: ctx.author (group sender) or ctx.from (dm sender)
  const wid = toText(ctx && (ctx.author || ctx.from));
  return extractDigits(wid) || wid;
}

function isFromMe(ctx) {
  return !!(ctx && ctx.fromMe);
}

function isCommandText(text, prefix) {
  const t = toText(text).trim();
  if (!t) return false;
  return t.startsWith(prefix);
}

function truncate(s, max) {
  const t = toText(s);
  if (max <= 0) return '';
  if (t.length <= max) return t;
  return t.slice(0, max - 3) + '...';
}

function extractTicket(text) {
  // TicketCore format: YYYYMMT##########
  const t = toText(text);
  const m = t.match(/(\d{6}T\d{10})/);
  return m ? m[1] : '';
}

module.exports = {
  init: (meta) => {
    const log = makeLogger(meta, 'FallbackCV');

    const implConfig = meta && meta.hubConf && meta.hubConf.implConfig ? meta.hubConf.implConfig : '';
    const conf = Conf.load(meta, implConfig);

    const enabled = conf.getBool('enabled', true);
    if (!enabled) {
      log.warn('disabled by config');
      return { onMessage: async () => null };
    }

    const controlGroupId = conf.getStr('controlGroupId', '');
    const sendService = conf.getStr('sendService', 'send');
    const commandService = conf.getStr('commandService', 'command');
    const accessService = conf.getStr('accessService', 'access');
    const requiredRole = conf.getStr('requiredRole', 'staff');

    const cmdReply = conf.getStr('cmdReply', 'r');

    const ticketType = conf.getStr('ticketType', 'fallback');
    const ticketStoreSpec = conf.getStr('ticketStoreSpec', 'jsonstore:Fallback/tickets');

    const forwardMyMessages = conf.getBool('forwardMyMessages', false);
    const includeBody = conf.getBool('includeBody', true);
    const includeMediaHint = conf.getBool('includeMediaHint', true);
    const maxBodyChars = conf.getInt('maxBodyChars', 1200);

    const send = meta.getService(sendService) || meta.getService('send');
    const access = meta.getService(accessService);
    const commands = meta.getService(commandService);

    if (!controlGroupId) {
      log.error('controlGroupId is empty in FallbackCV.conf');
      return { onMessage: async () => null };
    }
    if (!send) {
      log.error(`missing send service (${sendService})`);
      return { onMessage: async () => null };
    }

    // TicketCore config object
    const ticketCfg = {
      storeSpec: ticketStoreSpec,
      maxOpenPerChat: 50,
    };

    function isStaff(ctx) {
      if (!access) return false;
      const senderId = toText(ctx && ctx.senderId ? ctx.senderId : '');
      if (!senderId) return false;
      return access.hasAtLeast(senderId, requiredRole);
    }

    async function safeSend(chatId, text, opts) {
      try {
        await send(chatId, toText(text), opts || {});
        return true;
      } catch (e) {
        log.error(`send failed chatId=${chatId} err=${e && e.message ? e.message : String(e)}`);
        return false;
      }
    }

    function buildForwardText(ticket, customerWid, customerPhone, body, mediaHint) {
      const lines = [];
      lines.push('FALLBACK DM');
      lines.push(`Ticket: ${ticket}`);
      if (customerPhone) lines.push(`Customer: ${customerPhone}`);
      if (!customerPhone && customerWid) lines.push(`CustomerWid: ${customerWid}`);
      if (includeMediaHint && mediaHint) lines.push(`Media: ${mediaHint}`);
      if (includeBody) {
        const b = truncate(body, maxBodyChars);
        if (b) {
          lines.push('Message:');
          lines.push(b);
        }
      }
      lines.push('');
      lines.push('Reply: quote-reply this message OR use !r <ticket> <text>');
      return lines.join('\n');
    }

    async function forwardDmToControlGroup(ctx) {
      if (!ctx || ctx.isGroup) return false;
      if (isFromMe(ctx) && !forwardMyMessages) return false;

      const senderId = getSenderId(ctx);
      const dmWid = toText(ctx.from);

      // If DM is from staff/controller, do not forward (keep for commands/admin usage)
      const tmpCtx = Object.assign({}, ctx);
      tmpCtx.senderId = senderId;
      if (isStaff(tmpCtx)) return false;

      const body = toText(ctx.body || ctx.text || '');
      const mediaHint =
        ctx.hasMedia || (ctx.type && ctx.type !== 'chat')
          ? toText(ctx.type || 'media')
          : '';

      const ticketInfo = {
        chatId: dmWid,
        senderId: senderId,
        lastBody: truncate(body, 300),
      };

      const touched = await TicketCore.touch(meta, ticketCfg, ticketType, dmWid, {
        info: ticketInfo,
      });

      const ticket = touched && touched.ticket ? touched.ticket : '';
      if (!ticket) return false;

      const customerPhone = extractDigits(dmWid) || senderId;
      const forwardText = buildForwardText(ticket, dmWid, customerPhone, body, mediaHint);

      await safeSend(controlGroupId, forwardText);
      return true;
    }

    async function handleQuoteReply(ctx) {
      if (!ctx || !ctx.isGroup) return false;
      if (toText(ctx.from) !== controlGroupId) return false;

      const body = toText(ctx.body || ctx.text || '').trim();
      if (!body) return false;

      // Avoid stealing command messages
      const commandPrefix = '!';
      if (isCommandText(body, commandPrefix)) return false;

      // Only handle if user is staff/controller
      const senderId = getSenderId(ctx);
      const tmpCtx = Object.assign({}, ctx);
      tmpCtx.senderId = senderId;
      if (!isStaff(tmpCtx)) return false;

      // whatsapp-web.js quote
      if (!ctx.hasQuotedMsg || typeof ctx.getQuotedMessage !== 'function') return false;

      let quoted;
      try {
        quoted = await ctx.getQuotedMessage();
      } catch (e) {
        return false;
      }
      if (!quoted) return false;

      const quotedText = toText(quoted.body || quoted.text || '');
      const ticket = extractTicket(quotedText);
      if (!ticket) return false;

      const resolved = await TicketCore.resolve(meta, ticketCfg, ticketType, ticket, {});
      if (!resolved || !resolved.rec || !resolved.rec.chatId) {
        await safeSend(controlGroupId, `Ticket not found: ${ticket}`);
        return true;
      }

      const customerChatId = toText(resolved.rec.chatId);
      const sent = await safeSend(customerChatId, body);

      if (sent) {
        await safeSend(controlGroupId, `Replied OK: ${ticket}`);
      } else {
        await safeSend(controlGroupId, `Reply failed: ${ticket}`);
      }
      return true;
    }

    async function handleReplyCommand(ctx, args) {
      if (!ctx) return;
      if (toText(ctx.chatId || ctx.from) !== controlGroupId) {
        await ctx.reply('This command is only allowed in Control Group.');
        return;
      }
      if (!isStaff(ctx)) {
        await ctx.reply('Not allowed.');
        return;
      }

      const ticket = toText(args && args[0]).trim();
      const text = toText(args && args.slice(1).join(' ')).trim();

      if (!ticket || !text) {
        await ctx.reply(`Usage: !${cmdReply} <ticket> <text>`);
        return;
      }

      const resolved = await TicketCore.resolve(meta, ticketCfg, ticketType, ticket, {});
      if (!resolved || !resolved.rec || !resolved.rec.chatId) {
        await ctx.reply(`Ticket not found: ${ticket}`);
        return;
      }

      const customerChatId = toText(resolved.rec.chatId);
      const ok = await safeSend(customerChatId, text);
      if (ok) await ctx.reply(`Replied OK: ${ticket}`);
      else await ctx.reply(`Reply failed: ${ticket}`);
    }

    // Register secondary reply command: !r
    if (commands && typeof commands.register === 'function') {
      commands.register(cmdReply, handleReplyCommand, {
        desc: 'Fallback reply by ticket (secondary). Prefer quote-reply in Control Group.',
        usage: `!${cmdReply} <ticket> <text>`,
      });
    } else {
      log.warn(`command service not available (${commandService}); quote-reply will still work`);
    }

    log.info('ready');

    return {
      onMessage: async (ctx) => {
        // 1) Quote-reply in control group
        const handledQuote = await handleQuoteReply(ctx);
        if (handledQuote) return { stopPropagation: true };

        // 2) Forward DMs to control group
        if (ctx && !ctx.isGroup) {
          try {
            await forwardDmToControlGroup(ctx);
          } catch (e) {
            log.error(`forward failed err=${e && e.message ? e.message : String(e)}`);
          }
        }

        return null;
      },
    };
  },
};
