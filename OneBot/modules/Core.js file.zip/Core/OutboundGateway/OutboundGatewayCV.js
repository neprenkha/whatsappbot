"use strict";
module.exports = require("./OutboundGatewayV1");