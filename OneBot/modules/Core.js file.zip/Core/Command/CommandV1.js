'use strict';

// X:\OneBot\Modules\Core\CommandV1.js
// Wrapper to keep compatibility with older hubConf pointers.

module.exports = require('./Command/CommandV1');
