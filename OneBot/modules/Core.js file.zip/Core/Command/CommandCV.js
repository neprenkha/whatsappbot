"use strict";
module.exports = require("./CommandV1");
