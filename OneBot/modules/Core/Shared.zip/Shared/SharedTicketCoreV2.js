'use strict';

// SharedTicketCoreV2
// Ticket format: YYMMT + 7 digits (e.g. 2601T0000001)
//
// Storage:
// - ticketStoreSpec: jsonstore:<Namespace>/<Key>
//   Example: jsonstore:Fallback/tickets
//   The JsonStore service adds .json automatically, so do NOT include .json.
//
// API (compat with V1 call sites):
// - touch(meta, cfg, ticketType, chatId, info)
// - resolve(meta, cfg, ticketType, chatId)
// - get(meta, cfg, ticketId)
// - setStatus(meta, cfg, ticketId, status)
// - list(meta, cfg, opts)
// - next(meta, cfg, ticketType)

function cfgGetStr(cfg, key, defVal) {
  if (!cfg || typeof cfg !== 'object') return defVal;
  const v = cfg[key];
  if (v === undefined || v === null) return defVal;
  const s = String(v).trim();
  return s ? s : defVal;
}

function cfgGetInt(cfg, key, defVal) {
  const s = cfgGetStr(cfg, key, '');
  if (!s) return defVal;
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? n : defVal;
}

function normalizeTicketType(ticketType) {
  if (!ticketType) return 'ticket';
  return String(ticketType).trim().toLowerCase();
}

function parseJsonStoreSpec(spec) {
  const s = String(spec || '').trim();
  if (!s) return null;
  if (!s.toLowerCase().startsWith('jsonstore:')) return null;

  const rest = s.slice('jsonstore:'.length);
  const idx = rest.indexOf('/');
  const ns = idx >= 0 ? rest.slice(0, idx) : rest;
  const key = idx >= 0 ? rest.slice(idx + 1) : 'tickets';

  const cleanNs = String(ns || 'core').trim() || 'core';
  let cleanKey = String(key || 'tickets').trim() || 'tickets';
  if (cleanKey.toLowerCase().endsWith('.json')) {
    cleanKey = cleanKey.slice(0, -5);
  }
  return { ns: cleanNs, key: cleanKey };
}

function nowMs(meta) {
  // Prefer the canonical timezone service.
  const tz = meta && meta.getService ? meta.getService('timezone') : null;
  if (tz && typeof tz.nowMs === 'function') return tz.nowMs();
  return Date.now();
}

function yymmFromMs(ms) {
  const d = new Date(ms);
  const yy = String(d.getFullYear() % 100).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  return yy + mm;
}

async function openJsonStore(meta, spec) {
  const js = meta && meta.getService ? meta.getService('jsonstore') : null;
  if (!js || typeof js.open !== 'function') {
    throw new Error('jsonstore_service_missing');
  }

  const parsed = parseJsonStoreSpec(spec);
  if (!parsed) throw new Error('invalid_ticketStoreSpec');

  const nsStore = js.open(parsed.ns);
  if (!nsStore || typeof nsStore.get !== 'function' || typeof nsStore.set !== 'function') {
    throw new Error('jsonstore_namespace_invalid');
  }

  return { ns: parsed.ns, key: parsed.key, store: nsStore };
}

async function loadDoc(meta, cfg) {
  const ticketStoreSpec = cfgGetStr(cfg, 'ticketStoreSpec', '');
  const handle = await openJsonStore(meta, ticketStoreSpec);

  let doc = await handle.store.get(handle.key);
  if (!doc || typeof doc !== 'object') doc = {};
  if (!doc.tickets || typeof doc.tickets !== 'object') doc.tickets = {};
  if (!doc.seq || typeof doc.seq !== 'object') doc.seq = {};

  return { handle, doc };
}

async function saveDoc(handle, doc) {
  await handle.store.set(handle.key, doc);
}

function buildTicketId(yymm, seq) {
  const seqStr = String(seq).padStart(7, '0');
  return String(yymm) + 'T' + seqStr;
}

async function next(meta, cfg, ticketType) {
  const { handle, doc } = await loadDoc(meta, cfg);

  const type = normalizeTicketType(ticketType);
  const ms = nowMs(meta);
  const yymm = yymmFromMs(ms);

  const seqKey = type + ':' + yymm;
  const cur = doc.seq[seqKey] ? parseInt(doc.seq[seqKey], 10) : 0;
  const nextSeq = (Number.isFinite(cur) ? cur : 0) + 1;
  doc.seq[seqKey] = nextSeq;

  await saveDoc(handle, doc);
  return { ok: true, ticketId: buildTicketId(yymm, nextSeq), yymm, seq: nextSeq };
}

async function resolve(meta, cfg, ticketType, chatId) {
  if (!chatId) return { ok: false, reason: 'missingChatId' };
  const { handle, doc } = await loadDoc(meta, cfg);
  const type = normalizeTicketType(ticketType);
  const key = type + ':' + String(chatId).trim();
  const t = doc.tickets[key];
  if (!t) return { ok: false, reason: 'not_found' };
  return { ok: true, ticket: t, handle, doc, key };
}

async function touch(meta, cfg, ticketType, chatId, info) {
  if (!chatId) return { ok: false, reason: 'missingChatId' };

  const { handle, doc } = await loadDoc(meta, cfg);
  const type = normalizeTicketType(ticketType);
  const key = type + ':' + String(chatId).trim();

  const ms = nowMs(meta);
  const fromName =
    info && (info.fromName || info.name) ? String(info.fromName || info.name) : '';
  const fromPhone =
    info && (info.fromPhone || info.phone) ? String(info.fromPhone || info.phone) : '';

  let t = doc.tickets[key];
  if (t) {
    t.updatedAt = ms;
    if (fromName) t.fromName = fromName;
    if (fromPhone) t.fromPhone = fromPhone;
    await saveDoc(handle, doc);
    return { ok: true, ticket: t };
  }

  // Create new ticket.
  const yymm = yymmFromMs(ms);
  const seqKey = type + ':' + yymm;
  const cur = doc.seq[seqKey] ? parseInt(doc.seq[seqKey], 10) : 0;
  const nextSeq = (Number.isFinite(cur) ? cur : 0) + 1;
  doc.seq[seqKey] = nextSeq;

  const ticketId = buildTicketId(yymm, nextSeq);

  t = {
    id: ticketId,
    type,
    chatId: String(chatId).trim(),
    status: 'open',
    createdAt: ms,
    updatedAt: ms,
    fromName,
    fromPhone,
  };

  doc.tickets[key] = t;
  await saveDoc(handle, doc);
  return { ok: true, ticket: t };
}

async function get(meta, cfg, ticketId) {
  const { doc } = await loadDoc(meta, cfg);
  const tickets = doc.tickets || {};
  const id = String(ticketId || '').trim();
  if (!id) return { ok: false, reason: 'missingTicketId' };

  const keys = Object.keys(tickets);
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const t = tickets[k];
    if (t && t.id === id) return { ok: true, ticket: t };
  }
  return { ok: false, reason: 'not_found' };
}

async function setStatus(meta, cfg, ticketId, status) {
  const id = String(ticketId || '').trim();
  const st = String(status || '').trim().toLowerCase();
  if (!id) return { ok: false, reason: 'missingTicketId' };
  if (!st) return { ok: false, reason: 'missingStatus' };

  const { handle, doc } = await loadDoc(meta, cfg);
  const tickets = doc.tickets || {};
  const keys = Object.keys(tickets);
  let changed = false;
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const t = tickets[k];
    if (t && t.id === id) {
      t.status = st;
      t.updatedAt = nowMs(meta);
      changed = true;
      break;
    }
  }

  if (!changed) return { ok: false, reason: 'not_found' };
  await saveDoc(handle, doc);
  return { ok: true };
}

async function list(meta, cfg, opts = {}) {
  const type = normalizeTicketType(opts.ticketType || opts.type || '');
  const chatId = opts.chatId ? String(opts.chatId).trim() : '';
  const status = opts.status ? String(opts.status).trim().toLowerCase() : '';

  const { doc } = await loadDoc(meta, cfg);
  const tickets = doc.tickets || {};
  const out = [];
  const keys = Object.keys(tickets);
  for (let i = 0; i < keys.length; i++) {
    const t = tickets[keys[i]];
    if (!t) continue;
    if (type && t.type !== type) continue;
    if (chatId && t.chatId !== chatId) continue;
    if (status && String(t.status || '').toLowerCase() !== status) continue;
    out.push(t);
  }
  out.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  const limit = cfgGetInt(opts, 'limit', 0) || cfgGetInt(cfg, 'listLimit', 0) || 0;
  return { ok: true, tickets: limit > 0 ? out.slice(0, limit) : out };
}

module.exports = {
  next,
  resolve,
  touch,
  get,
  setStatus,
  list,
};
