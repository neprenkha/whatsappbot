'use strict';

function cfgGetStr(cfg, key, defVal) {
  if (!cfg) return defVal;
  try {
    if (typeof cfg.getStr === 'function') return cfg.getStr(key, defVal);
  } catch (_) {}
  const v = cfg[key];
  if (v === undefined || v === null || v === '') return defVal;
  return String(v);
}

function parseJsonStoreSpec(spec) {
  if (!spec) return null;
  if (typeof spec !== 'string') return null;
  const s = spec.trim();
  if (!s.toLowerCase().startsWith('jsonstore:')) return null;
  const body = s.substring('jsonstore:'.length);
  const parts = body.split('/').filter(Boolean);
  if (parts.length < 2) return null;
  return { ns: parts[0], key: parts.slice(1).join('/') };
}

function makeMemStore() {
  let doc = { tickets: {} };
  return {
    async load() {
      return doc;
    },
    async save(newDoc) {
      doc = newDoc && typeof newDoc === 'object' ? newDoc : { tickets: {} };
      if (!doc.tickets || typeof doc.tickets !== 'object') doc.tickets = {};
    }
  };
}

function makeJsonStore(meta, spec) {
  const js = meta && meta.getService ? meta.getService('jsonstore') : null;
  if (!js || !spec) return makeMemStore();
  const nsStore = js.open(spec.ns);
  return {
    async load() {
      const v = await nsStore.get(spec.key);
      if (!v || typeof v !== 'object') return { tickets: {} };
      if (!v.tickets || typeof v.tickets !== 'object') v.tickets = {};
      return v;
    },
    async save(newDoc) {
      const v = newDoc && typeof newDoc === 'object' ? newDoc : { tickets: {} };
      if (!v.tickets || typeof v.tickets !== 'object') v.tickets = {};
      await nsStore.set(spec.key, v);
    }
  };
}

function atomicWriteJson(filePath, data) {
  const fs = require('fs');
  const path = require('path');
  try {
    const dir = path.dirname(filePath);
    fs.mkdirSync(dir, { recursive: true });
    const tmpPath = filePath + '.tmp';
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmpPath, filePath);
  } catch (e) {
    console.error(`atomicWriteJson failed for ${filePath}: ${e.message}`);
  }
}

async function createStore(meta, cfg) {
  const storeSpec = parseJsonStoreSpec(
    cfgGetStr(cfg, 'ticketStoreSpec', '') || cfgGetStr(cfg, 'storeSpec', '')
  );
  const store = storeSpec ? makeJsonStore(meta, storeSpec) : makeMemStore();
  const doc = await store.load();
  if (!doc || typeof doc !== 'object') return { store, doc: { tickets: {} } };
  if (!doc.tickets || typeof doc.tickets !== 'object') doc.tickets = {};
  return { store, doc };
}

function normalizeTicketType(ticketType) {
  if (!ticketType) return 'ticket';
  return String(ticketType).trim().toLowerCase();
}

async function touch(meta, cfg, ticketType, chatId, info) {
  const { store, doc } = await createStore(meta, cfg);

  const type = normalizeTicketType(ticketType);
  const key = type + ':' + String(chatId || '').trim();
  if (!chatId) return { ok: false, reason: 'missingChatId' };

  const now = Date.now();
  const fromName = info?.fromName || info?.name || '';
  const fromPhone = info?.fromPhone || info?.phone || '';

  let t = doc.tickets[key];
  if (t) {
    t.updatedAt = now;
    if (fromName) t.fromName = fromName;
    if (fromPhone) t.fromPhone = fromPhone;
    await store.save(doc);
    return { ok: true, ticket: t };
  }

  const prefix = cfgGetStr(cfg, 'ticketPrefix', 'T');
  const seqDigits = parseInt(cfgGetStr(cfg, 'ticketSequenceDigits', '10'), 10) || 10;
  const ym = new Date(now);
  const y = String(ym.getFullYear());
  const m = String(ym.getMonth() + 1).padStart(2, '0');
  const idPrefix = y + m + prefix;

  const seqFile = cfgGetStr(cfg, 'ticketSequenceFile', '');
  let seq = 1;

  if (seqFile) {
    try {
      let state = {};
      if (fs.existsSync(seqFile)) {
        try {
          state = JSON.parse(fs.readFileSync(seqFile, 'utf8')) || {};
        } catch (_) {
          state = {};
        }
      }
      const todayKey = idPrefix;
      seq = (state[todayKey] || 0) + 1;
      state[todayKey] = seq;
      atomicWriteJson(seqFile, state);
    } catch (_) {
      seq = 1; // fallback
    }
  }

  const ticketId = idPrefix + String(seq).padStart(seqDigits, '0');
  t = {
    id: ticketId,
    type,
    chatId: String(chatId),
    status: 'open',
    createdAt: now,
    updatedAt: now,
    fromName,
    fromPhone
  };

  doc.tickets[key] = t;
  await store.save(doc);

  return { ok: true, ticket: t };
}

module.exports = {
  touch,
  normalizeTicketType
};