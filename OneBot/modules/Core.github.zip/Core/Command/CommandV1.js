'use strict';
module.exports = require('./CommandCV');
