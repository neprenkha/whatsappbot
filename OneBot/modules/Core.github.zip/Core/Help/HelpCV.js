"use strict";
module.exports = require("./HelpV1");