"use strict";
module.exports = require("./StatusFeedV1");