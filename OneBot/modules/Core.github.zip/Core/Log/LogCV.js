"use strict";
module.exports = require("./LogV2");