"use strict";
module.exports = require("./InboundFilterV1");