"use strict";
module.exports = require("./OutboxV1");