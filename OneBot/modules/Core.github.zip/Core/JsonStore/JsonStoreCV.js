"use strict";
module.exports = require("./JsonStoreV1");